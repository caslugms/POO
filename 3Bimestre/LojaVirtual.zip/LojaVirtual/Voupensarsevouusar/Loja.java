/*import java.util.ArrayList;

public class Loja {
    private String nome;
    private ArrayList<Produto> produtos;

    public Loja() {
        this.nome = null;
        this.produtos = new ArrayList<Produto>();
    }

    public Loja(String nome) {
        this.nome = nome;
        this.produtos = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(ArrayList<Produto> produtos) {
        this.produtos = produtos;
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public void removerProduto(Produto produto) {
        produtos.remove(produto);
    }

    @Override
    public String toString() {
        return "Loja [nome=" + nome + ", produtos=" + produtos + "]";
    }


}*/
